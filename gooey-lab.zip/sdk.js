/*
 * sdk.js — PlayGama Bridge wrapper for Gooey Lab.
 *
 * Loaded BEFORE the game scripts from index.html. Exposes a single global
 * `SDK` object. Every call is defensive: when the bridge script is absent
 * (plain browser, local play, no publisher host) everything degrades to a
 * no-op or an immediate `false`, so the game stays 100% playable.
 */
const SDK = (function () {
  const bridgePromise = (window.bridge && window.bridge.initialize)
    ? window.bridge.initialize().then(function () { return window.bridge; })
    : Promise.resolve(null);

  // Some hosts expose the support flags as getters rather than methods.
  function flag(b, name) {
    if (!b || !b.advertisement) return false;
    try {
      var v = b.advertisement[name];
      return typeof v === 'function' ? !!v() : !!v;
    } catch (e) {
      return false;
    }
  }

  function pick(b, path) {
    try {
      var cur = b;
      for (var i = 0; i < path.length; i++) {
        if (cur == null) return undefined;
        cur = cur[path[i]];
      }
      return cur;
    } catch (e) {
      return undefined;
    }
  }

  // Forward the caller's extra arguments into the handler, so callbacks and
  // payloads reach the bridge intact.
  const call = function (fn) {
    return function () {
      var args = Array.prototype.slice.call(arguments);
      return bridgePromise
        .then(function (b) { return fn.apply(null, [b].concat(args)); })
        .catch(function () { /* never throw upward */ });
    };
  };

  return {
    available: call(function (b) { return !!b; }),

    gameReady: call(function (b) {
      if (b && b.platform && b.platform.sendMessage) b.platform.sendMessage('game_ready');
    }),

    loadingProgress: call(function (b, p) {
      if (b && typeof b.setGameLoadingProgress === 'function') b.setGameLoadingProgress(p);
    }),

    levelMessage: call(function (b, name) {
      if (b && b.platform && b.platform.sendMessage) b.platform.sendMessage(name);
    }),

    /* true when the host can actually serve an interstitial */
    isInterstitialSupported: call(function (b) { return flag(b, 'isInterstitialSupported'); }),

    /* true when the host can actually serve a rewarded video */
    isRewardedSupported: call(function (b) { return flag(b, 'isRewardedSupported'); }),

    isAudioEnabled: call(function (b) {
      if (!b) return true;
      var v = pick(b, ['platform', 'isAudioEnabled']);
      return v === undefined ? true : !!v;
    }),

    interstitial: call(function (b, placement) {
      if (!flag(b, 'isInterstitialSupported')) return false;
      try {
        b.advertisement.showInterstitial(placement || 'interstitial');
        return true;
      } catch (e) {
        return false;
      }
    }),

    /*
     * Resolves true ONLY when the host reports the 'rewarded' state.
     * Closed / failed / unsupported all resolve false, so callers can never
     * grant a reward the player did not earn.
     */
    rewarded: call(function (b, placement) {
      if (!flag(b, 'isRewardedSupported')) return Promise.resolve(false);
      return new Promise(function (resolve) {
        var settled = false;
        var done = function (ok) { if (!settled) { settled = true; resolve(ok); } };
        var onState = function (state) {
          if (state === 'rewarded') done(true);
          else if (state === 'closed' || state === 'failed') done(false);
        };
        try {
          var names = b.EVENT_NAME || {};
          var evt = names.REWARDED_STATE_CHANGED || 'rewarded_state_changed';
          b.advertisement.on(evt, onState);
          b.advertisement.showRewarded(placement || 'rewarded');
        } catch (e) {
          done(false);
        }
        // Safety net: never leave the caller hanging if no state event arrives.
        setTimeout(function () { done(false); }, 120000);
      });
    }),

    onPlatformPause: call(function (b, cb) {
      try {
        if (!b) return;
        var evt = (b.EVENT_NAME && b.EVENT_NAME.PAUSE_STATE_CHANGED) || 'pause_state_changed';
        b.platform.on(evt, cb);
      } catch (e) {}
    }),

    onAudioChanged: call(function (b, cb) {
      try {
        if (!b) return;
        var evt = (b.EVENT_NAME && b.EVENT_NAME.AUDIO_STATE_CHANGED) || 'audio_state_changed';
        b.platform.on(evt, cb);
      } catch (e) {}
    }),

    storageGet: call(function (b, keys) {
      if (!b || !b.storage) return null;
      try { return b.storage.get(keys); } catch (e) { return null; }
    }),

    storageSet: call(function (b, key, value) {
      if (!b || !b.storage) return;
      try { b.storage.set(key, value); } catch (e) {}
    }),
  };
})();

window.SDK = SDK;