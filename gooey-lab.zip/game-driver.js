/*
 * game-driver.js — neutral offline driver for this build.
 *
 * Replaces the portal SDK wrapper that the portalbridge plugin
 * dynamically injects. Exposes the exact surface the
 * wrapper provided so the game keeps working with no network and no ads.
 * Loaded first from index.html so it exists before any game script runs.
 */
(function () {
	"use strict";

	// --- Neutral portal-compatible SDK surface -------------------------------
	var driver = {
		_debug: false,
		gameId: "offline",

		init: function (opts) {
			opts = opts || {};
			if (typeof opts.submitScore === "function") this._submitScore = opts.submitScore;
			return Promise.resolve();
		},
		setDebug: function (v) { this._debug = !!v; },

		// Loading / gameplay lifecycle
		gameLoadingStart: function () {},
		gameLoadingProgress: function () {},
		gameLoadingFinished: function () {},
		gameplayStart: function () {},
		gameplayStop: function () {},

		// Ads: resolve instantly. Callback-based APIs get called synchronously,
		// promise-based APIs resolve immediately so the game never freezes.
		commercialBreak: function (onStart) {
			if (typeof onStart === "function") {
				try { onStart(); } catch (e) {}
			}
			return Promise.resolve();
		},
		rewardedBreak: function (opts) {
			opts = opts || {};
			if (typeof opts.onStart === "function") {
				try { opts.onStart(); } catch (e) {}
			}
			// Return "reward granted" so rewarded flows stay playable offline.
			return Promise.resolve(true);
		},
		happyTime: function () {},

		// Analytics / misc
		measure: function () {},
		movePill: function () {},
		openExternalLink: function (url) {
			if (typeof url === "string" && /^https?:/i.test(url)) {
				try { window.open(url, "_blank"); } catch (e) {}
			}
		},
		shareableURL: function () { return Promise.resolve(""); },
		submitScore: function () {},
		setDataAnnotations: function () {},
		togglePlayerAdvertisingConsent: function () {}
	};

	window.PortalSDK = driver;

	// The wrapper script tag would normally define these flags.
	window.GetIsPortalPlatform = window.GetIsPortalPlatform || function () { return false; };
	window.GetIsPortalIFrame = function () { return false; };

	// Global recovery hook: if the runtime ever shows a crash dialog, reload
	// once (guarded by a cooldown so a persistent error can't loop).
	var lastReload = 0;
	setInterval(function () {
		var dialog = document.getElementById("crashDialog");
		if (dialog && Date.now() - lastReload > 30000) {
			lastReload = Date.now();
			location.reload();
		}
	}, 1500);
})();
