/*
 * playgama-hub.js — main-thread ad policy, persistence and reward UI.
 *
 * The Construct 3 game runs inside a Web Worker. This file is the ONLY place
 * that talks to the PlayGama Bridge, and it is the single owner of:
 *
 *   - the interstitial placement policy (2 consecutive same-outcome runs),
 *   - the rewarded-ad flows (revive once per run, victory bonus),
 *   - the DOM overlay that presents the reward buttons,
 *   - cloud-save mirroring through bridge.storage (localStorage fallback),
 *   - pause / audio-state propagation to the game.
 *
 * Protocol with the worker (BroadcastChannel "gooey-lab-bridge"):
 *
 *   worker -> main  ask(fn, args)          request/response
 *                   event(fn, args)        fire-and-forget
 *   main   -> worker grant(fn, args)        reward actually granted
 *
 * Everything degrades to a no-op when the bridge is absent, so the game is
 * fully playable with no publisher host.
 */
(function () {
  'use strict';

  var CHANNEL = 'gooey-lab-bridge';
  var SAVE_KEY = 'gooey_lab_save_v1';

  /* ------------------------------------------------------------------ *
   * Persistent state
   * ------------------------------------------------------------------ */
  var state = {
    coins: 0,
    streak: 0,          // consecutive finished runs with the same outcome
    streakOutcome: '',  // 'win' | 'loss'
    revivedThisRun: false
  };

  function loadLocal() {
    try {
      var raw = window.localStorage.getItem(SAVE_KEY);
      if (!raw) return;
      var data = JSON.parse(raw);
      if (!data || typeof data !== 'object') return;
      if (typeof data.coins === 'number' && isFinite(data.coins)) state.coins = data.coins;
    } catch (e) { /* a corrupted save is simply ignored */ }
  }

  function persist() {
    try {
      window.localStorage.setItem(SAVE_KEY, JSON.stringify(state));
    } catch (e) {}
    try {
      if (window.SDK && window.SDK.storageSet) {
        window.SDK.storageSet('localStorage:' + SAVE_KEY, JSON.stringify(state));
      }
    } catch (e) {}
  }

  function hydrateFromCloud() {
    // Restore the coin balance so rewarded bonuses survive a reinstall.
    // The game's own save file is never touched.
    try {
      if (!window.SDK || !window.SDK.storageGet) return;
      var key = 'localStorage:' + SAVE_KEY;
      Promise.resolve(window.SDK.storageGet([key])).then(function (res) {
        var v = res && res[key];
        if (typeof v !== 'string' || !v) return;
        var data = JSON.parse(v);
        if (data && typeof data.coins === 'number' && isFinite(data.coins)) {
          state.coins = data.coins;
        }
      }).catch(function () {});
    } catch (e) {}
  }

  /* ------------------------------------------------------------------ *
   * Overlay UI
   * ------------------------------------------------------------------ */
  var ui = null;

  function ensureUi() {
    if (ui) return ui;

    var host = document.createElement('div');
    host.id = 'gooey-bridge-ui';
    host.setAttribute('role', 'group');
    host.setAttribute('aria-label', 'Game options');
    host.style.cssText =
      'position:fixed;left:0;right:0;bottom:0;display:flex;justify-content:center;' +
      'align-items:center;padding:12px;z-index:2147483000;pointer-events:none;' +
      'font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;';

    var banner = document.createElement('div');
    banner.id = 'gooey-bridge-banner';
    banner.style.cssText =
      'display:none;align-items:center;gap:12px;padding:10px 14px;border-radius:12px;' +
      'background:rgba(16,16,22,.94);color:#fff;font-size:15px;line-height:1.35;' +
      'pointer-events:auto;box-shadow:0 6px 24px rgba(0,0,0,.5);max-width:94vw;' +
      'border:1px solid rgba(255,255,255,.14);';

    var label = document.createElement('span');
    label.id = 'gooey-bridge-label';

    var btn = document.createElement('button');
    btn.id = 'gooey-bridge-btn';
    btn.type = 'button';
    btn.style.cssText =
      'border:0;border-radius:9px;padding:10px 15px;background:#2f9e44;color:#fff;' +
      'font-weight:700;font-size:15px;cursor:pointer;white-space:nowrap;' +
      'font-family:inherit;min-height:44px;';
    btn.addEventListener('click', function () { onBannerClick(); });

    banner.appendChild(label);
    banner.appendChild(btn);
    host.appendChild(banner);
    document.body.appendChild(host);

    ui = { host: host, banner: banner, label: label, btn: btn };
    return ui;
  }

  var pendingAction = null;   // function() -> Promise<boolean>
  var actionBusy = false;

  function showBanner(text, buttonText, action) {
    var o = ensureUi();
    o.label.textContent = text;
    o.btn.textContent = buttonText;
    o.banner.style.display = 'flex';
    pendingAction = action || null;
  }

  function hideBanner() {
    if (!ui) return;
    ui.banner.style.display = 'none';
    pendingAction = null;
  }

  function onBannerClick() {
    if (actionBusy || !pendingAction) return;
    actionBusy = true;
    var action = pendingAction;
    Promise.resolve().then(action).catch(function () {}).then(function () {
      actionBusy = false;
    });
  }

  /* ------------------------------------------------------------------ *
   * Channel plumbing
   * ------------------------------------------------------------------ */
  var bc = null;
  try { bc = new BroadcastChannel(CHANNEL); } catch (e) { bc = null; }

  var pending = {};

  function reply(id, payload) {
    if (!bc || !id) return;
    try { bc.postMessage(Object.assign({ id: id }, payload)); } catch (e) {}
  }

  function event(fn, args) {
    if (!bc) return;
    try { bc.postMessage({ event: fn, args: args || [] }); } catch (e) {}
  }

  function ask(fn, args) {
    if (!bc) return Promise.resolve(null);
    return new Promise(function (resolve) {
      var id = 'q' + Math.random().toString(36).slice(2);
      var timer = setTimeout(function () {
        if (pending[id]) { delete pending[id]; resolve(null); }
      }, 180000);
      pending[id] = function (result) {
        clearTimeout(timer);
        delete pending[id];
        resolve(result);
      };
      try {
        bc.postMessage({ id: id, fn: fn, args: args || [] });
      } catch (e) {
        clearTimeout(timer);
        delete pending[id];
        resolve(null);
      }
    });
  }

  /* ------------------------------------------------------------------ *
   * Bridge helpers
   * ------------------------------------------------------------------ */
  function interstitialSupported() {
    return Promise.resolve(window.SDK.isInterstitialSupported()).catch(function () { return false; });
  }

  function rewardedSupported() {
    return Promise.resolve(window.SDK.isRewardedSupported()).catch(function () { return false; });
  }

  // Resolves true ONLY when the host reports the 'rewarded' state.
  function showRewardedVideo(placement) {
    return rewardedSupported().then(function (supported) {
      if (!supported) return false;
      return Promise.resolve(window.SDK.rewarded(placement || 'rewarded'))
        .catch(function () { return false; });
    });
  }

  /* ------------------------------------------------------------------ *
   * Interstitial policy — 2 consecutive same-outcome runs
   * ------------------------------------------------------------------ */
  var interstitialBusy = false;

  function maybeInterstitial() {
    if (interstitialBusy) return Promise.resolve(false);
    interstitialBusy = true;

    return interstitialSupported()
      .then(function (supported) {
        if (!supported) return false;
        if (state.streak < 2) return false;
        // Consume the streak: the next interstitial needs two fresh runs.
        state.streak = 0;
        state.streakOutcome = '';
        persist();
        return Promise.resolve(window.SDK.interstitial('interstitial'))
          .then(function (shown) { return !!shown; })
          .catch(function () { return false; });
      })
      .catch(function () { return false; })
      .then(function (result) {
        interstitialBusy = false;
        return result;
      });
  }

  /* ------------------------------------------------------------------ *
   * Run lifecycle
   * ------------------------------------------------------------------ */
  function recordRun(outcome) {
    state.runsPlayed = (state.runsPlayed || 0) + 1;
    state.revivedThisRun = false;

    if (state.streakOutcome === outcome) {
      state.streak += 1;
    } else {
      state.streak = 1;
      state.streakOutcome = outcome;
    }

    var earned = outcome === 'win' ? 25 : 5;
    state.coins += earned;
    persist();
    return earned;
  }

  /* ------------------------------------------------------------------ *
   * Message handling (requests from the worker)
   * ------------------------------------------------------------------ */
  function handle(fn, args, id) {
    switch (fn) {

      // Called at the natural pause after a finished run.
      case 'run_finished':
        var outcome = args[0] === 'win' ? 'win' : 'loss';
        var earned = recordRun(outcome);
        // Interstitial first (policy-gated), then the reward offer. Never two
        // ads back to back.
        return maybeInterstitial().then(function () {
          reply(id, { result: { earned: earned, outcome: outcome } });
          if (outcome === 'win') offerDoubleBonus(earned);
          else offerRevive();
        });

      // The worker asks whether a rewarded option may be shown at all.
      case 'can_reward':
        return rewardedSupported().then(function (ok) { reply(id, { result: ok }); });

      case 'coins':
        return Promise.resolve(reply(id, { result: state.coins }));

      case 'set_coins':
        state.coins = Number(args[0]) || 0;
        persist();
        return Promise.resolve(reply(id, { result: state.coins }));

      // Ad requests coming from the game's own portalbridge call sites.
      case 'interstitial':
        return maybeInterstitial().then(function (shown) {
          reply(id, { result: shown });
        });

      case 'rewarded':
        return showRewardedVideo(args[0]).then(function (ok) {
          reply(id, { result: ok });
        });

      case 'platform_message':
        return Promise.resolve(sendPlatformMessage(args[0])).then(function () {
          reply(id, { result: true });
        });

      default:
        return Promise.resolve(reply(id, { result: null }));
    }
  }

  /* ------------------------------------------------------------------ *
   * Rewarded flows
   * ------------------------------------------------------------------ */

  // Game over -> REVIVE, once per run.
  function offerRevive() {
    rewardedSupported().then(function (supported) {
      if (!supported) return;          // hidden entirely, REPLAY is untouched
      if (state.revivedThisRun) return;
      showBanner(
        'Watch a short video to continue this run right where you left off.',
        'WATCH AD - REVIVE',
        function () {
          return showRewardedVideo('revive').then(function (ok) {
            hideBanner();
            if (!ok) return false;     // no reward, the run simply ends
            state.revivedThisRun = true;
            persist();
            event('grant', ['revive']);
            return true;
          });
        }
      );
    }).catch(function () {});
  }

  // Victory -> DOUBLE BONUS. Base reward is always kept.
  function offerDoubleBonus(earned) {
    rewardedSupported().then(function (supported) {
      if (!supported) return;
      showBanner(
        'Level cleared! You earned ' + earned + ' coins.',
        'WATCH AD - DOUBLE COINS',
        function () {
          return showRewardedVideo('double_bonus').then(function (ok) {
            hideBanner();
            if (!ok) return false;
            state.coins += earned;     // bonus on top of the base reward
            persist();
            event('grant', ['double_bonus']);
            return true;
          });
        }
      );
    }).catch(function () {});
  }

  /* ------------------------------------------------------------------ *
   * Platform lifecycle
   * ------------------------------------------------------------------ */
  // Forward a lifecycle message to the host through the bridge.
  function sendPlatformMessage(name) {
    try {
      if (window.SDK && window.SDK.levelMessage) window.SDK.levelMessage(name);
    } catch (e) {}
  }

  function wirePlatform() {
    // Subscribe ONCE to pause and audio. The worker pauses gameplay AND mutes
    // SFX on either event (the host fires them for tab switches and ad opens).
    try {
      window.SDK.onPlatformPause(function () {
        event('platform_pause', []);
      });
      window.SDK.onAudioChanged(function (enabled) {
        event('audio_state', [!!enabled]);
      });
    } catch (e) {}

    Promise.resolve(window.SDK.isAudioEnabled())
      .then(function (enabled) { event('audio_state', [enabled !== false]); })
      .catch(function () {});

    Promise.resolve(window.SDK.available()).then(function (ok) {
      if (ok) window.SDK.gameReady();
    }).catch(function () {});
  }

  /* ------------------------------------------------------------------ *
   * Boot
   * ------------------------------------------------------------------ */
  if (bc) {
    bc.onmessage = function (ev) {
      var msg = ev.data || {};
      if (msg.id && pending[msg.id]) {
        var fn = pending[msg.id];
        delete pending[msg.id];
        fn(msg.result);
        return;
      }
      if (msg.fn) {
        handle(msg.fn, msg.args || [], msg.id);
        return;
      }

      // Fire-and-forget notifications from the game worker.
      if (msg.event === 'loading_progress') {
        var p = Number(msg.args && msg.args[0]);
        if (isFinite(p)) {
          Promise.resolve(window.SDK.loadingProgress(Math.max(0, Math.min(1, p)))).catch(function () {});
        }
        return;
      }
      if (msg.event === 'platform_message') {
        sendPlatformMessage(msg.args && msg.args[0]);
        return;
      }
      if (msg.event === 'grant') {
        return;   // the reward is acted on inside the worker
      }
    };
  }

  loadLocal();
  hydrateFromCloud();
  wirePlatform();

  window.GooeyLabBridge = {
    ask: ask,
    event: event,
    hideBanner: hideBanner,
    getCoins: function () { return state.coins; }
  };
})();