# Gooey Lab

A squishy physics platformer: stretch, fling, bounce and flip gravity through
70 hand-built rooms of a mad scientist's laboratory.

Play with the arrow keys / A-D to move, Space / Up / W to jump (hold for a
higher bounce), and R to reset the current room. On touch devices use the
on-screen arrows, jump button and reset button.

## Controls
- **Move:** Arrow keys or A-D (on-screen arrows / drag zones on touch)
- **Jump:** Space, Up or W (hold for extra height)
- **Reset room:** R (on-screen reset button)

## About this build

This is an offline build of Gooey Lab with the **PlayGama Bridge SDK**
integrated for the publisher network.

- `sdk.js` - defensive wrapper around the PlayGama Bridge. Every call is a
  safe no-op when the bridge is absent, so the game is fully playable in a
  plain browser.
- `playgama-hub.js` - main-thread ad policy, persistence and the reward UI.
- `scripts/project/playgama-bridge.js` - worker-side half that answers the
  game's ad call sites and reports the level lifecycle.
- `playgama-bridge-config.json` - empty config the bridge looks for on load.

Ads follow the placement policy: interstitials only after two consecutive
finished runs with the same outcome, and rewarded video only where the player
opts in (revive at the end of a run, doubled reward on a cleared level).
Rewards are granted only when the video is watched to completion.