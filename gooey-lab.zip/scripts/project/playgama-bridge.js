/*
 * playgama-bridge.js — worker-side half of the PlayGama integration.
 *
 * Loaded inside the Construct 3 worker (see scripts/c3main.js). It supplies
 * the "portal SDK" DOM side that this export is missing, routing the game's
 * existing ad call sites through the PlayGama Bridge on the main thread.
 *
 * Responsibilities:
 *   - answer the portalbridge plugin messages (GameplayStart/Stop,
 *     Interstitial, Rewarded, LoadingEnd, SendEvent, MovePill, ...),
 *   - drive loading progress from the real loading layout,
 *   - detect finished runs and report the outcome so the main thread can
 *     apply the interstitial placement policy (2 consecutive same outcomes),
 *   - implement REVIVE (resume the run in place, once per run),
 *   - pause gameplay and mute SFX on platform pause / audio-state change.
 *
 * The main-thread half lives in playgama-hub.js and is the only code that
 * touches the bridge. Communication uses a BroadcastChannel so the game
 * scripts stay untouched. Everything degrades to a no-op without the bridge.
 */

/* global BroadcastChannel */

runOnStartup(async (runtime) => {
  'use strict';

  var CHANNEL = 'gooey-lab-bridge';

  var bc = null;
  try { bc = new BroadcastChannel(CHANNEL); } catch (e) { bc = null; }

  var pending = {};
  var revivedThisRun = false;   // REVIVE is allowed once per run
  var revivedLevel = null;      // level on which a revive was already spent
  var runLevel = null;          // level currently being played
  var lossReported = false;
  var winReported = false;

  /* ---------------------------------------------------------------- *
   * Channel helpers
   * ---------------------------------------------------------------- */
  function ask(fn, args) {
    if (!bc) return Promise.resolve(null);
    return new Promise(function (resolve) {
      var id = 'w' + Math.random().toString(36).slice(2);
      var timer = setTimeout(function () {
        if (pending[id]) { delete pending[id]; resolve(null); }
      }, 180000);
      pending[id] = function (result) {
        clearTimeout(timer);
        delete pending[id];
        resolve(result);
      };
      try {
        bc.postMessage({ id: id, fn: fn, args: args || [] });
      } catch (e) {
        clearTimeout(timer);
        delete pending[id];
        resolve(null);
      }
    });
  }

  function event(fn, args) {
    if (!bc) return;
    try { bc.postMessage({ event: fn, args: args || [] }); } catch (e) {}
  }

  /* ---------------------------------------------------------------- *
   * Incoming messages from the main thread
   * ---------------------------------------------------------------- */
  if (bc) {
    bc.onmessage = function (ev) {
      var msg = ev.data || {};

      // Response to one of our own requests.
      if (msg.id && pending[msg.id]) {
        var resolvePending = pending[msg.id];
        delete pending[msg.id];
        resolvePending(msg.result);
        return;
      }

      if (!msg.event) return;

      switch (msg.event) {
        case 'grant':
          if (msg.args && msg.args[0] === 'revive') doRevive();
          return;
        case 'platform_pause':
          setSuspended(true);
          muteAll(true);
          event('platform_message', ['level_paused']);
          return;
        case 'audio_state':
          muteAll(!(msg.args && msg.args[0]));
          return;
        default:
          return;
      }
    };
  }

  /* ---------------------------------------------------------------- *
   * Runtime helpers
   * ---------------------------------------------------------------- */
  function layoutName() {
    try { return runtime.layout.name; } catch (e) { return ''; }
  }

  function isLevelLayout(name) {
    return /^level\d+$/.test(name || '');
  }

  function setSuspended(flag) {
    try { runtime.sdk.setSuspended(!!flag); } catch (e) {}
  }

  // Mute every sound effect the game is playing.
  function muteAll(muted) {
    try {
      var audioObjs = runtime.objects.Audio.getAllInstances();
      for (var i = 0; i < audioObjs.length; i++) {
        var inst = audioObjs[i];
        if (inst.behaviors && inst.behaviors.Audio) {
          inst.behaviors.Audio.volume = muted ? 0 : 1;
        }
      }
    } catch (e) {}
    try {
      if (typeof AudioContext !== 'undefined' || typeof webkitAudioContext !== 'undefined') {
        // Nothing global to touch: Construct owns the AudioContext.
      }
    } catch (e) {}
  }

  /* ---------------------------------------------------------------- *
   * The portalbridge DOM side
   *
   * The export ships the plugin's worker half but not its DOM half, so every
   * ad call used to resolve to nothing. We answer those messages here and
   * route them through the PlayGama Bridge on the main thread.
   * ---------------------------------------------------------------- */
  function installPortalBridge() {
    var plugin = null;
    try { plugin = globalThis.C3.Plugins.portalbridge; } catch (e) { plugin = null; }
    if (!plugin || !plugin.Instance) return false;

    var proto = plugin.Instance.prototype;

    proto.Interstitial = function (tag) {
      var self = this;
      return ask('interstitial', [tag]).then(function (shown) {
        self.lastAdTag = tag;
        self._trigger('OnIntertsitialComplete');
        return !!shown;
      });
    };

    proto.Rewarded = function (tag) {
      var self = this;
      return ask('rewarded', [tag]).then(function (ok) {
        self.lastRewardedSuccess = !!ok;
        self.lastAdTag = tag;
        self._trigger('OnRewardedComplete');
        return !!ok;
      });
    };

    proto.GameplayStart = function () { event('gameplay_start'); };
    proto.GameplayStop = function () { event('gameplay_stop'); };
    proto.LoadingEnd = function () { event('loading_end'); };
    proto.SendEvent = function () { /* analytics: no external calls allowed */ };
    proto.MovePill = function () { /* portal chrome: not applicable here */ };
    proto.SubmitScore = function () { event('submit_score'); };
    proto.OpenExternalLink = function () { /* outgoing links are forbidden */ };
    proto.GetShareableURL = function () { return Promise.resolve(''); };
    proto.GetToken = function () { return Promise.resolve(''); };
    proto.Login = function () { return Promise.resolve(''); };

    return true;
  }

  /* ---------------------------------------------------------------- *
   * REVIVE — resume the run exactly where it ended
   * ---------------------------------------------------------------- */
  function doRevive() {
    if (revivedThisRun) return;
    revivedThisRun = true;
    lossReported = true;   // the run continues, do not count it as a loss twice

    var lvl = null;
    try { lvl = runtime.globalVars.current_level; } catch (e) {}
    if (runLevel !== null) lvl = runLevel;
    revivedLevel = lvl;

    // Reset the death counter and re-enter the same level so the run resumes
    // in place: same level, same progress.
    setTimeout(function () {
      try {
        runtime.globalVars.death_amount = 0;
        runtime.globalVars.restarting = false;
      } catch (e) {}
    }, 0);

    try {
      if (lvl) {
        runtime.goToLayout('level' + lvl);
        return;
      }
    } catch (e) {}

    try {
      var name = layoutName();
      if (isLevelLayout(name)) runtime.goToLayout(name);
    } catch (e) {}
  }

  /* ---------------------------------------------------------------- *
   * Loading progress
   * ---------------------------------------------------------------- */
  function startLoadingWatcher() {
    var lastPct = -1;
    var seenLoader = false;
    var iv = setInterval(function () {
      var name = layoutName();

      if (name === 'LOADER') {
        seenLoader = true;
        var pct = 0;
        try { pct = Number(runtime.globalVars.loading_percent) || 0; } catch (e) {}
        if (pct !== lastPct) {
          lastPct = pct;
          event('loading_progress', [Math.max(0, Math.min(1, pct / 100))]);
        }
        return;
      }

      // Stop once loading finished and we moved on to real gameplay.
      if (seenLoader && isLevelLayout(name)) {
        clearInterval(iv);
        event('loading_progress', [1]);
      }
    }, 120);
    setTimeout(function () { clearInterval(iv); }, 180000);
  }

  /* ---------------------------------------------------------------- *
   * Level lifecycle + finished-run detection
   * ---------------------------------------------------------------- */

  // The game itself shows its ad button once the player has died 3 times,
  // which is its natural "run over" moment. Use the same threshold.
  var LOSS_DEATH_THRESHOLD = 3;

  function reportRun(outcome) {
    if (outcome === 'win') {
      if (winReported) return;
      winReported = true;
    } else {
      if (lossReported) return;
      lossReported = true;
    }
    event('gameplay_stop');
    if (outcome === 'win') event('platform_message', ['level_completed']);
    else event('platform_message', ['level_failed']);
    ask('run_finished', [outcome]);
  }

  function installLifecycleWatchers() {
    runtime.getAllLayouts().forEach(function (layout) {
      layout.addEventListener('afterlayoutstart', function () {
        var name = layout.name;
        if (name === 'LOADER') return;

        if (isLevelLayout(name)) {
          // The layout name is the level being played. Moving forward to a
          // higher-numbered level means the previous one was cleared, so the
          // win is reported right here at the transition.
          var entered = parseInt(name.replace('level', ''), 10) || 0;
          var previous = runLevel;
          runLevel = entered;

          if (previous !== null && entered > previous) {
            reportRun('win');
          }

          if (runLevel !== revivedLevel) revivedThisRun = false;
          lossReported = false;
          winReported = false;
          event('gameplay_start');
          event('platform_message', ['level_started']);
          return;
        }

        if (name === 'level_select') {
          event('gameplay_stop');
        }
      });
    });

    var iv = setInterval(function () {
      if (!isLevelLayout(layoutName())) return;
      var gv = runtime.globalVars;
      var lvl = gv.current_level;
      var deaths = gv.death_amount;

      if (runLevel === null) runLevel = lvl;

      // Safety net for the case where the level clears without a layout
      // change: current_level moved past the level being played.
      if (lvl > runLevel) {
        reportRun('win');
        return;
      }

      // The player used up the run: the game treats 3 deaths as the point
      // where it offers its own "watch ad" button, so that is the run-over
      // moment. Below it, dying simply restarts the level and is NOT a
      // finished run (and must not trigger a revive offer either).
      // A revive already spent on this level must never re-trigger.
      if (deaths >= LOSS_DEATH_THRESHOLD && !lossReported && !revivedThisRun
          && revivedLevel !== runLevel) {
        reportRun('loss');
      }
    }, 400);

    setTimeout(function () { clearInterval(iv); }, 60 * 60 * 1000);
  }

  /* ---------------------------------------------------------------- *
   * Boot
   * ---------------------------------------------------------------- */
  startLoadingWatcher();
  installPortalBridge();
  installLifecycleWatchers();

});