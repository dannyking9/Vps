import "./../box2d.wasm.js";
import "./c3runtime.js";
import "./plugins/portalbridge/c3runtime/main.js";
import "./objRefTable.js";
import "./project/main.js";
import "./project/javaScriptInEvents.js";
import "./project/playgama-bridge.js";
